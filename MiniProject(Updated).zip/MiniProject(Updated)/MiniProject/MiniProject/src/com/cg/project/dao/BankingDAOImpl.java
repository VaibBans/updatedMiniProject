package com.cg.project.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashMap;

import com.cg.project.bean.AccountBean;
import com.cg.project.bean.CustomerBean;
import com.cg.project.bean.TransactionsBean;
import com.cg.project.bean.UserBean;
import com.cg.project.exception.BankingException;
import com.cg.project.util.DBUtil;

public class BankingDAOImpl {

	UserBean user = new UserBean();
	TransactionsBean transactionsBean;
	public UserBean validateLogin(int accId) throws BankingException{
		Connection conn = null;
		PreparedStatement pst = null;
		String qry = "SELECT USER_ID, LOGIN_PASSWORD FROM USERTABLE WHERE ACCOUNT_ID=?";
		try{
			conn = DBUtil.createConnection();
			pst = conn.prepareStatement(qry);
			pst.setLong(1, user.getAccountId());
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				user.setNumberId(rs.getLong(1));
				user.setLoginPassword(rs.getString(2));
			}
		}catch(SQLException se){
			/* Applying exception */
			
			throw new BankingException("User Name does not exist");
		}
		return user;
	}

	public int newUserLogin(UserBean user) throws BankingException{
		int status = 0;
		Connection conn = null;
		PreparedStatement pst = null;
		try{
			conn = DBUtil.createConnection();
			String sql1 = "INSERT INTO USERTABLE(USER_ID,LOGIN_PASSWORD,SECRET_QUESTION,TRANSACTION_PASSWORD) VALUES (?,?,?,?)";
			pst = conn.prepareStatement(sql1);
			pst.setLong(1, user.getNumberId());
			pst.setString(2, user.getLoginPassword());
			pst.setString(3, user.getLockStatus());
			pst.setString(4, user.getTransactionPassword());

			status = pst.executeUpdate();
		}catch(SQLException se){
////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////			
			/*see the exception message*/
			throw new BankingException("");
		}
		return status;
	}


	//open account 
	public int fetchAccounts(long actId) throws BankingException
	{
		int count = 0;
		Connection conn = null;
		PreparedStatement pst = null;
	try{
		conn = DBUtil.createConnection();
	
		String sql = "Select count(*) from accountmaster where account_Id="+actId;
		pst = conn.prepareStatement(sql);
		ResultSet rs = pst.executeQuery();
		while(rs.next()) {
			count = rs.getInt(1);
		}
	}catch(SQLException se){
////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
		/*Select the message*/
		throw new BankingException("");
	}
		return count;
	}
	
	//show balance   
	public double fetchAmount(long actId) throws BankingException
	{
		int amt = 0;
		Connection conn = null;
		PreparedStatement pst = null;
		try{
		conn = DBUtil.createConnection();
		String sql = "Select ACCOUNT_BALANCE from accountmaster where account_Id="+actId;
		pst = conn.prepareStatement(sql);
		ResultSet rs = pst.executeQuery();
		while(rs.next()) {
			amt= rs.getInt(1);
		}
	}catch(SQLException se){
////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
/*Select the message*/

		throw new BankingException("");
	}
		return amt;
	}

	public long openAccount(CustomerBean customerBean) throws BankingException
	{
		int count = 0;
		long acId=0;
		Connection conn =null;
		PreparedStatement pst= null;
		String sql = new String("INSERT INTO customer VALUES(acc_seq.nextval,?,?,?,?,?)");
		try{
			conn = DBUtil.createConnection();
			//	System.out.println("***********************"+connStudent);
			pst = conn.prepareStatement(sql);
			//pst.setLong(1,customerBean.getAccountId());
			pst.setString(1,customerBean.getCustomerName());
			pst.setString(2,customerBean.getEmail());
			pst.setString(3,customerBean.getAddress());
			pst.setString(4,customerBean.getPancard());
			pst.setString(5,customerBean.getAccountType());

			//pstStudent.setString(6,bookingBean.getDateOfTransport());
			count = pst.executeUpdate();

			conn = null;
			pst = null;
			conn = DBUtil.createConnection();
			sql = "Select account_id from customer";
			pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();

			while(rs.next()) {
				acId = rs.getLong(1);
			}
			customerBean.setAccountId(acId);
		}
		catch(SQLException se)
		{
////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
/*Select the message*/
			throw new BankingException("");
			//	throw new BookingException("Record not inserted: ");
		}finally{
			try{
				DBUtil.closeConnection();
			}catch(SQLException se){
				throw new BankingException("Problems in closing connection");
			}
			System.out.println(count+" results affected");
			System.out.println("accountId is: "+acId);
		}
		return acId;
	}

	public int validateId(long actId) throws BankingException
	{
		int count = 0;
		Connection conn = null;
		PreparedStatement pst = null;
		try{
		conn = DBUtil.createConnection();
		String sql = "Select count(*) from customer where account_Id="+actId;
		pst = conn.prepareStatement(sql);
		ResultSet rs = pst.executeQuery();
		while(rs.next()) {
			count = rs.getInt(1);
		}
		}catch(SQLException se){
////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
/*Select the message*/

			throw new BankingException("");
		}
		return count;
	}
	
///////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////
// see the try and catch block and see the usage of accType
	public String deposit(long actId,double amount,AccountBean accountBean) throws BankingException {
		String actType = "";
		Connection conn = null;
		PreparedStatement pst = null;
		try{
		conn = DBUtil.createConnection();
		// getting acct type for accountmaster table...
		String sql = "Select account_type from customer where account_Id="+actId;
		pst = conn.prepareStatement(sql);
		ResultSet rs = pst.executeQuery();
		while(rs.next()) {
			actType = rs.getString(1);
		}
		System.out.println("act type is: "+actType);
		}catch(SQLException se){
			throw new BankingException("");
		}
		pst=null; 
		conn = null;
		Date openDate=null;
//here check the value of actType as if we want to print different messages in both the exception
		System.out.println("account type in deposit"+actType);
		String sql1 = "INSERT INTO ACCOUNTMASTER VALUES(?,?,?,?)";
		int count = 0;
		try{
			conn = DBUtil.createConnection();
			//	System.out.println("***********************"+connStudent);
			pst = conn.prepareStatement(sql1);
			pst.setLong(1,actId);
			pst.setString(2,actType);
			pst.setDouble(3,amount);
			LocalDate date = LocalDate.now();
			openDate = Date.valueOf(date);
			pst.setDate(4,openDate);

			count = pst.executeUpdate();
		}catch(SQLException se)
		{
			System.out.println("unique constraint violated");
			throw new BankingException("Record not inserted: ");
		}finally{
			try{
				DBUtil.closeConnection();
			}catch(SQLException se){
				throw new BankingException("Problems in closing connection");
			}
		}
		if(count==0) {
			System.out.println(count+" results inserted");}
		//String out = "amount+\" is deposited in \"+actId+\" on date \"+openDate";
		return ("Deposited");
	}

	public String depositUpdate(long actId,double amount) throws BankingException {
		Connection conn = null;
		PreparedStatement pst = null;
		//Date openDate=null;
		// NEED TO UPDATE DATE ALSO .. 

		String sql1 = "UPDATE ACCOUNTMASTER SET ACCOUNT_BALANCE = ? WHERE ACCOUNT_ID = ?";
		int count = 0;
		try{
			conn = DBUtil.createConnection();
			pst = conn.prepareStatement(sql1);
			pst.setDouble(1,amount);
			pst.setLong(2, actId);
			count = pst.executeUpdate();
			System.out.println(count);

		}catch(SQLException se)
		{
//////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
//Select the message			
			throw new BankingException("");

		}finally{
			try{
				DBUtil.closeConnection();
			}catch(SQLException se){
				throw new BankingException("Problems in closing connection");
			}
		}
		if(count==0) {
			System.out.println(count+" results updated...");}
		return("Deposited");
	}

	public void transactionUpdate(long accId,TransactionsBean transBean ) throws BankingException
	{
		Connection conn = null;
		PreparedStatement pst = null;
		//	conn = DBUtil.createConnection();
		//double transAmt=0;
		//Date transDate=null;
		//first fetching account details on which transaction is done ...
		//String sql = "SELECT OPEN_DATE FROM ACCOUNTMASTER WHERE ACCOUNT_ID="+accId;
		//String sql = "INSERT INTO TRANSACTION_MASTER "
		//pst = conn.prepareStatement(sql);
		//ResultSet rs = pst.executeQuery();
		//TransactionsBean trans = new TransactionsBean();
		//while(rs.next()) {
		//transAmt = rs.getDouble(1);
		//transDate = rs.getDate(1);//keeping all dates as sysdate
		//}
		//	System.out.println("account details obtained...");
		// insert transaction record...
		String sql1 = "INSERT INTO TRANSACTIONS VALUES(tran_seq.nextval,?,?,?,?,?)";
		int count = 0;
		try{
			conn = DBUtil.createConnection();
			//	System.out.println("***********************"+connStudent);
			pst = conn.prepareStatement(sql1);
			pst.setString(1,transBean.getTransDescription());
			LocalDate tdate = LocalDate.now();
			Date trdate = Date.valueOf(tdate);
			pst.setDate(2,trdate);
			pst.setString(3,transBean.getTransactionType());
			pst.setDouble(4,transBean.getTransactionAmount());
			pst.setLong(5,accId);
			count = pst.executeUpdate();

		}catch(SQLException se)
		{
			throw new BankingException("Record not inserted: ");
		}finally{
			try{
				DBUtil.closeConnection();
			}catch(SQLException se){
				throw new BankingException("Problems in closing connection");
			}
		}
		System.out.println(count+" trans results inserted");
		//return count;
	}

	public String withdraw(long accId,double amount) throws BankingException 
	{
		Connection conn = null;
		PreparedStatement pst = null;
		//Date openDate=null;
		// NEED TO UPDATE DATE ALSO .. 

		String sql1 = "UPDATE ACCOUNTMASTER SET ACCOUNT_BALANCE = ACCOUNT_BALANCE-? WHERE ACCOUNT_ID = ?";
		int count = 0;
		try{
			conn = DBUtil.createConnection();
			pst = conn.prepareStatement(sql1);
			pst.setDouble(1,amount);
			pst.setLong(2, accId);
			count = pst.executeUpdate();
			System.out.println(count);

		}catch(SQLException se)
		{
			
//////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
// Select messages			
			throw new BankingException("");

		}finally{
			try{
				DBUtil.closeConnection();
			}catch(SQLException se){
				throw new BankingException("Problems in closing connection");
			}
		}

		if(count==0) {
			System.out.println(count+" results updated...");}
		return(""+amount+" is withdrawn");	
	}

	public void sendfund(double amt, long actId, long pactId) throws BankingException{
		Connection conn = null;
		PreparedStatement pst = null;
		String sql1 = "UPDATE ACCOUNTMASTER SET ACCOUNT_BALANCE = ACCOUNT_BALANCE-? WHERE ACCOUNT_ID = ?";
		int count = 0;
		try{
			conn = DBUtil.createConnection();
			pst = conn.prepareStatement(sql1);
			pst.setDouble(1,amt);
			pst.setLong(2, actId);
			count = pst.executeUpdate();
			System.out.println(count+"account updated...");

			count = 0;
			String sql2 = "UPDATE ACCOUNTMASTER SET ACCOUNT_BALANCE = ACCOUNT_BALANCE+? WHERE ACCOUNT_ID = ?";
			pst = conn.prepareStatement(sql2);
			pst.setDouble(1,amt);
			pst.setLong(2, pactId);
			count = pst.executeUpdate();
			System.out.println(count+"account updated...");

			//insert in fund transfer
			//conn = null;
			pst = null;
			int temp=0;
			String sql = "INSERT INTO FUND_TRANSFER VALUES(fund_seq.nextval,?,?,?,?)";
			//conn = DBUtil.createConnection();
			//	System.out.println("***********************"+connStudent);
			pst = conn.prepareStatement(sql);
			pst.setLong(1,actId);
			pst.setLong(2,pactId);
			//pst.setDouble(3,amount);
			LocalDate date = LocalDate.now();
			Date openDate = Date.valueOf(date);
			pst.setDate(3,openDate);
			pst.setDouble(4,amt);
			temp = pst.executeUpdate();
			System.out.println(temp+"fund record inserted...");
		}catch(SQLException se)
		{
			se.printStackTrace();
		}finally{
			try{
				DBUtil.closeConnection();
			}catch(SQLException se){
				se.printStackTrace();
				//throw new BookingException("Problems in closing connection");
			}
		}
	}
	public String validatePassword(long userId){
		Connection conn = null;
		String pwd=null;
		PreparedStatement pst = null;
		try{
			conn = DBUtil.createConnection();
			String sql = "Select login_password from usertable where user_id=?";
			pst = conn.prepareStatement(sql);
			pst.setLong(1, userId);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				pwd = rs.getString(1);
			}
		}catch(SQLException se){
			se.printStackTrace();
		}	
		return pwd;
	}
	/*public String updateUser(long uId){
		Connection conn = null;
		PreparedStatement pst = null;
		try{
			conn = DBUtil.createConnection();
			String qry = "UPDATE TABLE USERTABLE SET ACCOUNT_ID=?";

		}
	}*/
	public HashMap<Long, TransactionsBean> viewMiniStatement(long accId){
		Date dateOfTrans = null;
		HashMap<Long, TransactionsBean> miniMap = new HashMap<>();
		/*List<TransactionsBean> dateOfTransList = new ArrayList<TransactionsBean>();*/
		Connection conn = null;
		PreparedStatement pst = null;
		try{
			//WE CAN USE ORDER BY EITHER BY DATEOFTRANSACTIONS OR TRANSACTION ID (SEQUENCE)
			String sql = "select * from (select * from TRANSACTIONS order by DATEOFTRANSACTION desc) where rownum<=10 and account_id ="+accId;
			pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				transactionsBean = new TransactionsBean(rs.getLong(1),rs.getString(2),rs.getDate(3),rs.getString(4),rs.getDouble(5),rs.getLong(6));
				miniMap.put(accId,transactionsBean);
			}
		}catch(SQLException se){
			se.getMessage();
		}
		return miniMap;
	}
	public HashMap<Long, TransactionsBean> viewDetailedStatement(long accId){
		Date dateOfTrans = null;
		HashMap<Long, TransactionsBean> detMap = new HashMap<>();
		Connection conn = null;
		PreparedStatement pst = null;
		try{
			conn = DBUtil.createConnection();
			String sql = "SELECT * FROM TRANSACTIONS WHERE ACCOUNT_ID="+accId;
			pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				transactionsBean = new TransactionsBean(rs.getLong(1),rs.getString(2),rs.getDate(3),rs.getString(4),rs.getDouble(5),rs.getLong(6));
				detMap.put(accId, transactionsBean);
			}
		}catch(SQLException se){
			se.printStackTrace();
		}
		return detMap;
	}
}


