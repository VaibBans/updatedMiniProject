package com.cg.project.dao;

import java.util.HashMap;

import com.cg.project.bean.AccountBean;
import com.cg.project.bean.CustomerBean;
import com.cg.project.bean.TransactionsBean;
import com.cg.project.bean.UserBean;
import com.cg.project.exception.BankingException;

public interface IBankingDAO 
{
	public UserBean validateLogin(int accId) throws BankingException;
	public int newUserLogin(UserBean user) throws BankingException;
	public int fetchAccounts(long actId) throws BankingException;
	public double fetchAmount(long actId) throws BankingException;
	public long openAccount(CustomerBean customerBean) throws BankingException;
	public int validateId(long actId) throws BankingException;
	public String deposit(long actId,double amount,AccountBean accountBean) throws BankingException;
	public String depositUpdate(long actId,double amount) throws BankingException;
	public void transactionUpdate(long accId,TransactionsBean transBean ) throws BankingException;
	public String withdraw(long accId,double amount) throws BankingException;
	public void sendfund(double amt, long actId, long pactId) throws BankingException;
	public String validatePassword(long userId) throws BankingException;
	public HashMap<Long, TransactionsBean> viewMiniStatement(long accId) throws BankingException;
	public HashMap<Long, TransactionsBean> viewDetailedStatement(long accId) throws BankingException;
	
}
