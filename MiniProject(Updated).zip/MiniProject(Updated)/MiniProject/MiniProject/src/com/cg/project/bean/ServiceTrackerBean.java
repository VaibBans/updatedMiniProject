package com.cg.project.bean;

import java.util.Date;

public class ServiceTrackerBean {
private long serviceId;
private String serviceDescription;
private long accountId;
private Date serviceRaisedDate;
private String serviceStatus;

}
